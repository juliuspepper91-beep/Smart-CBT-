export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  questions: Question[];
  createdAt: number;
}

export interface ExamResult {
  id: string;
  examId: string;
  examTitle: string;
  studentId: string;
  studentName: string;
  score: number;
  totalQuestions: number;
  completedAt: number;
  answers: number[];
}

export interface StudentProgress {
  studentId: string;
  examId: string;
  answers: number[];
  currentIndex: number;
  timeLeft: number;
}

export interface Teacher {
  id: string;
  email: string;
  password: string;
  name: string;
}

export interface StudentProfile {
  id: string;
  portalName: string;
  password: string;
  fullName: string;
  status?: 'active' | 'suspended';
}

export interface SystemSettings {
  schoolName: string;
  allowSelfSignup: boolean;
  examRetakes: boolean;
}

export interface ExamLog {
  id: string;
  studentId: string;
  examId: string;
  action: string;
  timestamp: number;
}
