import { useState, useEffect } from 'react';
import { Play, ClipboardList, PlusCircle, CheckCircle2, Clock, User, LogOut, ChevronRight, ChevronLeft, Trash2, Trophy, ShieldCheck, Mail, Lock, UserPlus, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Exam, Question, ExamResult, Teacher, StudentProfile, ExamLog } from './types';

const generateId = () => Math.random().toString(36).substr(2, 9);
import { INITIAL_EXAMS } from './data';

export function App() {
  const [view, setView] = useState<'landing' | 'student-login' | 'teacher-login' | 'teacher-signup' | 'teacher-dashboard' | 'exam-taking' | 'exam-setup' | 'results' | 'manage-students' | 'system-logs'>('landing');
  
  // Storage hooks
  const [exams, setExams] = useState<Exam[]>(() => {
    const saved = localStorage.getItem('cbt_exams');
    return saved ? JSON.parse(saved) : INITIAL_EXAMS;
  });
  const [results, setResults] = useState<ExamResult[]>(() => {
    const saved = localStorage.getItem('cbt_results');
    return saved ? JSON.parse(saved) : [];
  });
  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    const saved = localStorage.getItem('cbt_teachers');
    return saved ? JSON.parse(saved) : [];
  });
  const [students, setStudents] = useState<StudentProfile[]>(() => {
    const saved = localStorage.getItem('cbt_students');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentTeacher, setCurrentTeacher] = useState<Teacher | null>(null);
  const [currentStudent, setCurrentStudent] = useState<StudentProfile | null>(null);
  const [systemLogs, setSystemLogs] = useState<ExamLog[]>(() => {
    const saved = localStorage.getItem('cbt_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // Form states
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [studentPortalId, setStudentPortalId] = useState('');
  const [studentPassword, setStudentPassword] = useState('');

  const [currentExam, setCurrentExam] = useState<Exam | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [studentAnswers, setStudentAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [activeResult, setActiveResult] = useState<ExamResult | null>(null);
  const [showInstructions, setShowInstructions] = useState(false);
  const [isExamMode, setIsExamMode] = useState(false);

  // Security: Prevent window closing/refreshing during exam
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isExamMode) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isExamMode]);

  // Security: Lock student in exam view
  useEffect(() => {
    if (view === 'exam-taking') {
      setIsExamMode(true);
    } else {
      setIsExamMode(false);
    }
  }, [view]);

  // Persistence
  useEffect(() => {
    localStorage.setItem('cbt_exams', JSON.stringify(exams));
  }, [exams]);
  useEffect(() => {
    localStorage.setItem('cbt_results', JSON.stringify(results));
  }, [results]);
  useEffect(() => {
    localStorage.setItem('cbt_teachers', JSON.stringify(teachers));
  }, [teachers]);
  useEffect(() => {
    localStorage.setItem('cbt_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('cbt_logs', JSON.stringify(systemLogs));
  }, [systemLogs]);

  const addLog = (studentId: string, examId: string, action: string) => {
    const newLog: ExamLog = {
      id: generateId(),
      studentId,
      examId,
      action,
      timestamp: Date.now()
    };
    setSystemLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  // Auto-save progress for students
  useEffect(() => {
    if (view === 'exam-taking' && currentStudent && currentExam) {
      const progress = {
        studentId: currentStudent.id,
        examId: currentExam.id,
        answers: studentAnswers,
        currentIndex: currentQuestionIndex,
        timeLeft
      };
      localStorage.setItem(`progress_${currentStudent.id}_${currentExam.id}`, JSON.stringify(progress));
    }
  }, [studentAnswers, currentQuestionIndex, timeLeft, view]);

  // Timer logic
  useEffect(() => {
    let timer: any;
    if (view === 'exam-taking' && timeLeft > 0 && !showInstructions) {
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            submitExam();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [view, timeLeft, showInstructions]);

  const resumeExam = (exam: Exam) => {
    if (!currentStudent) return;
    const saved = localStorage.getItem(`progress_${currentStudent.id}_${exam.id}`);
    if (saved) {
      const progress = JSON.parse(saved);
      setCurrentExam(exam);
      setStudentAnswers(progress.answers);
      setCurrentQuestionIndex(progress.currentIndex);
      setTimeLeft(progress.timeLeft);
      setShowInstructions(false);
      setView('exam-taking');
    }
  };

  const handleTeacherSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail || !authPassword || !authName) return alert('Fill all fields');
    if (teachers.find(t => t.email === authEmail)) return alert('Email already exists');
    
    const newTeacher = { id: generateId(), email: authEmail, password: authPassword, name: authName };
    setTeachers([...teachers, newTeacher]);
    setCurrentTeacher(newTeacher);
    setView('teacher-dashboard');
    resetAuthForms();
  };

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const teacher = teachers.find(t => t.email === authEmail && t.password === authPassword);
    if (teacher) {
      setCurrentTeacher(teacher);
      setView('teacher-dashboard');
      resetAuthForms();
    } else {
      alert('Invalid credentials');
    }
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find(s => s.portalName === studentPortalId && s.password === studentPassword);
    if (student) {
      setCurrentStudent(student);
      setView('student-login');
      resetAuthForms();
    } else {
      alert('Invalid Portal ID or Password');
    }
  };

  const generateStudent = (fullName: string) => {
    const portalName = 'STU-' + Math.floor(1000 + Math.random() * 9000);
    const password = Math.random().toString(36).slice(-6);
    const newStudent = { id: generateId(), fullName, portalName, password };
    setStudents([...students, newStudent]);
  };

  const resetAuthForms = () => {
    setAuthEmail('');
    setAuthPassword('');
    setAuthName('');
    setStudentPortalId('');
    setStudentPassword('');
  };

  const startExam = (exam: Exam) => {
    // Standard validation: Check if student already has a high score/completed this exam
    const previousResult = results.find(r => r.studentId === currentStudent?.id && r.examId === exam.id);
    if (previousResult) {
      if (!confirm(`You have already taken this exam (Score: ${previousResult.score}/${previousResult.totalQuestions}). Do you want to retake it? Previous results will be kept.`)) {
        return;
      }
    }

    if (currentStudent) {
      addLog(currentStudent.id, exam.id, 'Initiated Exam Session');
    }

    // Check if there is existing progress
    const saved = localStorage.getItem(`progress_${currentStudent?.id}_${exam.id}`);
    if (saved) {
      if (confirm('You have an unfinished attempt. Do you want to resume where you left off?')) {
        addLog(currentStudent!.id, exam.id, 'Resumed Exam Session');
        resumeExam(exam);
        return;
      }
    }

    setCurrentExam(exam);
    setStudentAnswers(new Array(exam.questions.length).fill(-1));
    setCurrentQuestionIndex(0);
    setTimeLeft(exam.duration * 60);
    setShowInstructions(true);
    setView('exam-taking');
  };

  const submitExam = () => {
    if (!currentExam || !currentStudent) return;
    
    // Check if already submitted (prevent double submissions)
    const alreadySubmitted = results.find(r => r.studentId === currentStudent.id && r.examId === currentExam.id && (Date.now() - r.completedAt < 5000));
    if (alreadySubmitted) return;

    let score = 0;
    currentExam.questions.forEach((q, idx) => {
      if (studentAnswers[idx] === q.correctAnswer) {
        score++;
      }
    });

    const result: ExamResult = {
      id: generateId(),
      examId: currentExam.id,
      examTitle: currentExam.title,
      studentId: currentStudent.id,
      studentName: currentStudent.fullName,
      score,
      totalQuestions: currentExam.questions.length,
      completedAt: Date.now(),
      answers: [...studentAnswers]
    };

    // Use functional update to ensure we have latest state
    setResults(prev => {
      const updated = [...prev, result];
      localStorage.setItem('cbt_results', JSON.stringify(updated));
      return updated;
    });

    setActiveResult(result);
    addLog(currentStudent.id, currentExam.id, `Submitted Exam: ${score}/${currentExam.questions.length}`);
    localStorage.removeItem(`progress_${currentStudent.id}_${currentExam.id}`);
    setIsExamMode(false);
    setView('results');
  };

  const exportResults = () => {
    if (results.length === 0) {
      alert("No results available to export.");
      return;
    }

    // Standard CSV headers and data mapping
    const headers = ['Student ID', 'Student Name', 'Exam Title', 'Raw Score', 'Total Questions', 'Percentage (%)', 'Date', 'Time'];
    const data = results.map(r => {
      const student = students.find(s => s.id === r.studentId);
      const date = new Date(r.completedAt);
      return [
        student?.portalName || 'N/A',
        `"${r.studentName.replace(/"/g, '""')}"`, // Escape quotes for CSV
        `"${r.examTitle.replace(/"/g, '""')}"`,
        r.score,
        r.totalQuestions,
        ((r.score / r.totalQuestions) * 100).toFixed(2),
        date.toLocaleDateString(),
        date.toLocaleTimeString()
      ];
    });

    const csvContent = [headers, ...data].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `SmartCBT_Results_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url); // Clean up
  };

  const handleCreateExam = (newExam: Exam) => {
    setExams(prev => [...prev, newExam]);
    setView('teacher-dashboard');
  };

  const deleteExam = (id: string) => {
    setExams(prev => prev.filter(e => e.id !== id));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const logout = () => {
    setCurrentTeacher(null);
    setCurrentStudent(null);
    setView('landing');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Navigation / Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => !currentExam && setView('landing')}
          >
            <div className="bg-indigo-600 p-2 rounded-lg">
              <ClipboardList className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">SmartCBT</span>
          </div>
          
          <div className="flex items-center gap-4">
            {(currentTeacher || currentStudent) && !currentExam && (
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-slate-500 hidden sm:block">
                  {currentTeacher ? `Teacher: ${currentTeacher.name}` : `Student: ${currentStudent?.fullName}`}
                </span>
                <button 
                  onClick={logout}
                  className="text-rose-600 hover:bg-rose-50 px-3 py-1.5 rounded-lg font-medium text-sm flex items-center gap-1 transition-colors"
                >
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>
            )}
            {view !== 'landing' && !currentTeacher && !currentStudent && (
              <button 
                onClick={() => setView('landing')}
                className="text-slate-600 hover:text-indigo-600 font-medium text-sm flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" /> Back Home
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {/* Landing View */}
          {view === 'landing' && (
            <motion.div 
              key="landing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center py-12"
            >
              <h1 className="text-5xl font-extrabold text-slate-900 mb-6">
                Modern Computer Based Testing
              </h1>
              <p className="text-xl text-slate-600 mb-12 max-w-2xl mx-auto">
                Secure examination portal for students and robust management for teachers.
              </p>
              
              <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                <div 
                  onClick={() => setView('student-login')}
                  className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 hover:border-indigo-500 hover:shadow-xl transition-all cursor-pointer group"
                >
                  <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-600 transition-colors">
                    <User className="w-8 h-8 text-indigo-600 group-hover:text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2 text-indigo-900">Student Portal</h2>
                  <p className="text-slate-500">Log in with your Portal ID and Password to take exams.</p>
                </div>

                <div 
                  onClick={() => setView('teacher-login')}
                  className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 hover:border-emerald-500 hover:shadow-xl transition-all cursor-pointer group"
                >
                  <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-600 transition-colors">
                    <ShieldCheck className="w-8 h-8 text-emerald-600 group-hover:text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2 text-emerald-900">Teacher Login</h2>
                  <p className="text-slate-500">Manage exams, student credentials, and review scores.</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Teacher Login */}
          {view === 'teacher-login' && (
            <motion.div key="teacher-login" className="max-w-md mx-auto">
              <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
                <h2 className="text-2xl font-bold mb-6 text-center">Teacher Login</h2>
                <form onSubmit={handleTeacherLogin} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                      <input type="email" required value={authEmail} onChange={e => setAuthEmail(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="teacher@school.com" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                      <input type="password" required value={authPassword} onChange={e => setAuthPassword(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="••••••••" />
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-shadow shadow-md">Login to Dashboard</button>
                </form>
                <div className="mt-6 text-center text-sm">
                  <span className="text-slate-500">Don't have an account?</span>{' '}
                  <button onClick={() => setView('teacher-signup')} className="text-emerald-600 font-bold hover:underline">Sign up</button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Teacher Signup */}
          {view === 'teacher-signup' && (
            <motion.div key="teacher-signup" className="max-w-md mx-auto">
              <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
                <h2 className="text-2xl font-bold mb-6 text-center">Create Teacher Account</h2>
                <form onSubmit={handleTeacherSignup} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                      <input type="text" required value={authName} onChange={e => setAuthName(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="John Doe" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                      <input type="email" required value={authEmail} onChange={e => setAuthEmail(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="teacher@school.com" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Create Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                      <input type="password" required value={authPassword} onChange={e => setAuthPassword(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="••••••••" />
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-shadow shadow-md">Create Account</button>
                </form>
                <div className="mt-6 text-center text-sm">
                  <span className="text-slate-500">Already have an account?</span>{' '}
                  <button onClick={() => setView('teacher-login')} className="text-emerald-600 font-bold hover:underline">Login</button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Student Portal Login (Modified) */}
          {view === 'student-login' && !currentStudent && (
            <motion.div 
              key="student-login-form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-200"
            >
              <h2 className="text-2xl font-bold mb-6 text-center text-indigo-900">Student Access</h2>
              <form onSubmit={handleStudentLogin} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Portal ID</label>
                  <input 
                    type="text" 
                    required
                    value={studentPortalId}
                    onChange={(e) => setStudentPortalId(e.target.value.toUpperCase())}
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. STU-1234"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                  <input 
                    type="password" 
                    required
                    value={studentPassword}
                    onChange={(e) => setStudentPassword(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Enter your password"
                  />
                </div>
                <button type="submit" className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 shadow-md">Login to Student Portal</button>
              </form>
              <p className="mt-6 text-center text-xs text-slate-400 uppercase tracking-widest font-semibold">Contact your teacher for credentials</p>
            </motion.div>
          )}

          {/* Student Exam Selection (After Login) */}
          {view === 'student-login' && currentStudent && (
            <motion.div key="student-portal-active" className="max-w-4xl mx-auto space-y-8">
               <div className="bg-indigo-600 p-8 rounded-2xl text-white shadow-lg flex flex-col md:flex-row justify-between items-center gap-4">
                  <div>
                    <h2 className="text-3xl font-bold">Welcome, {currentStudent.fullName}!</h2>
                    <p className="opacity-80">Your Portal ID: {currentStudent.portalName}</p>
                  </div>
                  <div className="bg-white/10 px-6 py-3 rounded-xl backdrop-blur-sm text-center">
                    <div className="text-sm uppercase tracking-wider opacity-70">Exams Completed</div>
                    <div className="text-3xl font-black">{results.filter(r => r.studentId === currentStudent.id).length}</div>
                  </div>
               </div>
               
               <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="font-bold text-slate-700 text-xl px-2">Assigned Exams</h3>
                    {exams.length === 0 ? (
                      <p className="text-slate-400 p-4">No exams currently assigned.</p>
                    ) : (
                      exams.map(exam => (
                        <div 
                          key={exam.id}
                          className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center justify-between hover:shadow-md transition-shadow"
                        >
                          <div>
                            <div className="font-bold text-lg text-slate-800">{exam.title}</div>
                            <div className="text-sm text-slate-500 flex items-center gap-3 mt-2">
                              <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {exam.duration}m</span>
                              <span className="flex items-center gap-1"><ClipboardList className="w-4 h-4" /> {exam.questions.length} Qs</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => startExam(exam)}
                            className="bg-indigo-600 text-white px-4 py-2 rounded-xl hover:bg-indigo-700 font-bold flex items-center gap-2 text-sm"
                          >
                            Start <Play className="w-4 h-4 fill-current" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-bold text-slate-700 text-xl px-2 flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-amber-500" /> Performance History
                    </h3>
                    <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-50">
                      {results.filter(r => r.studentId === currentStudent.id).length === 0 ? (
                        <div className="p-12 text-center text-slate-400">You haven't taken any exams yet.</div>
                      ) : (
                        results.filter(r => r.studentId === currentStudent.id).reverse().map(r => (
                          <div key={r.id} className="p-4 flex items-center justify-between">
                            <div>
                              <div className="font-bold text-slate-800">{r.examTitle}</div>
                              <div className="text-xs text-slate-400">{new Date(r.completedAt).toLocaleDateString()}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-black text-indigo-600">{r.score}/{r.totalQuestions}</div>
                              <div className="text-[10px] uppercase font-bold text-emerald-500">
                                {Math.round((r.score / r.totalQuestions) * 100)}%
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
               </div>
            </motion.div>
          )}

          {/* Manage Students View (Teacher) */}
          {view === 'manage-students' && currentTeacher && (
             <motion.div key="manage-students" className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-3xl font-bold">Manage Students</h2>
                  <button onClick={() => setView('teacher-dashboard')} className="text-slate-500 font-semibold hover:text-slate-800 flex items-center gap-1">
                    <ChevronLeft className="w-5 h-5" /> Back to Dashboard
                  </button>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-fit">
                    <h3 className="font-bold mb-4 flex items-center gap-2"><UserPlus className="w-5 h-5 text-indigo-600" /> Register Student</h3>
                    <div className="space-y-4">
                      <input id="stu-name-input" type="text" placeholder="Student Full Name" className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                      <button 
                        onClick={() => {
                          const input = document.getElementById('stu-name-input') as HTMLInputElement;
                          if (input.value) {
                            generateStudent(input.value);
                            input.value = '';
                          }
                        }}
                        className="w-full bg-indigo-600 text-white py-2 rounded-lg font-bold hover:bg-indigo-700"
                      >
                        Generate Login
                      </button>
                    </div>
                  </div>

                  <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-sm uppercase">
                        <tr>
                          <th className="px-6 py-4">Name</th>
                          <th className="px-6 py-4">Portal ID</th>
                          <th className="px-6 py-4">Password</th>
                          <th className="px-6 py-4 text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {students.length === 0 ? (
                          <tr><td colSpan={4} className="px-6 py-8 text-center text-slate-400">No students registered yet</td></tr>
                        ) : (
                          students.map(s => (
                            <tr key={s.id}>
                              <td className="px-6 py-4 font-semibold">{s.fullName}</td>
                              <td className="px-6 py-4"><code className="bg-slate-100 px-2 py-1 rounded text-indigo-600 font-bold">{s.portalName}</code></td>
                              <td className="px-6 py-4 text-slate-500">{s.password}</td>
                              <td className="px-6 py-4 text-center">
                                <button onClick={() => setStudents(prev => prev.filter(st => st.id !== s.id))} className="text-rose-500 hover:text-rose-700 p-1"><Trash2 className="w-4 h-4" /></button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
             </motion.div>
          )}

          {/* System Logs View */}
          {view === 'system-logs' && currentTeacher && (
             <motion.div key="system-logs" className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-3xl font-bold">Audit Logs</h2>
                  <button onClick={() => setView('teacher-dashboard')} className="text-slate-500 font-semibold hover:text-slate-800 flex items-center gap-1">
                    <ChevronLeft className="w-5 h-5" /> Back to Dashboard
                  </button>
                </div>
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                  <div className="divide-y divide-slate-100">
                    {systemLogs.length === 0 ? (
                      <div className="p-12 text-center text-slate-400">No system activities recorded yet.</div>
                    ) : (
                      systemLogs.map(log => {
                        const student = students.find(s => s.id === log.studentId);
                        const exam = exams.find(e => e.id === log.examId);
                        return (
                          <div key={log.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                            <div className="flex items-center gap-4">
                              <div className="w-2 h-2 rounded-full bg-indigo-400"></div>
                              <div>
                                <div className="text-sm font-bold text-slate-800">
                                  {student?.fullName || 'Unknown Student'}
                                </div>
                                <div className="text-xs text-slate-500">
                                  Performed: <span className="font-semibold text-indigo-600">{log.action}</span> for {exam?.title || 'Unknown Exam'}
                                </div>
                              </div>
                            </div>
                            <div className="text-xs text-slate-400 font-medium">
                              {new Date(log.timestamp).toLocaleTimeString()}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
             </motion.div>
          )}

          {/* Exam Setup (Teacher) */}
          {view === 'exam-setup' && (
            <ExamCreator onSave={handleCreateExam} onCancel={() => setView('teacher-dashboard')} />
          )}

          {/* Teacher Dashboard */}
          {view === 'teacher-dashboard' && currentTeacher && (
            <motion.div key="teacher-dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold">Teacher Dashboard</h2>
                  <p className="text-slate-500">Welcome back, {currentTeacher.name}</p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={exportResults}
                    className="bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl font-semibold flex items-center gap-2 hover:bg-slate-50 transition-colors"
                  >
                    Export Results
                  </button>
                  <button 
                    onClick={() => setView('manage-students')}
                    className="bg-white border border-indigo-200 text-indigo-600 px-4 py-2.5 rounded-xl font-semibold flex items-center gap-2 hover:bg-indigo-50 transition-colors"
                  >
                    <Users className="w-5 h-5" /> Students
                  </button>
                  <button 
                    onClick={() => setView('system-logs')}
                    className="bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl font-semibold flex items-center gap-2 hover:bg-slate-50 transition-colors"
                  >
                    System Logs
                  </button>
                  <button 
                    onClick={() => setView('exam-setup')}
                    className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-semibold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
                  >
                    <PlusCircle className="w-5 h-5" /> New Exam
                  </button>
                </div>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Exams', val: exams.length, icon: ClipboardList, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                  { label: 'Students', val: students.length, icon: Users, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Submissions', val: results.length, icon: CheckCircle2, color: 'text-amber-600', bg: 'bg-amber-50' },
                  { label: 'Avg Score', val: results.length ? `${Math.round(results.reduce((a,b) => a + (b.score/b.totalQuestions), 0) / results.length * 100)}%` : '0%', icon: Trophy, color: 'text-rose-600', bg: 'bg-rose-50' }
                ].map((stat, i) => (
                  <div key={i} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
                    <div className={`${stat.bg} ${stat.color} p-3 rounded-xl`}><stat.icon className="w-6 h-6" /></div>
                    <div>
                      <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{stat.label}</div>
                      <div className="text-2xl font-black">{stat.val}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  <h3 className="text-xl font-bold text-slate-700 mb-4 flex items-center gap-2">
                    <ClipboardList className="w-5 h-5" /> Exam Repository
                  </h3>
                  {exams.length === 0 ? (
                    <div className="bg-white p-12 text-center rounded-2xl border-2 border-dashed border-slate-200 text-slate-400">
                       No exams created yet.
                    </div>
                  ) : (
                    exams.map(exam => (
                      <div key={exam.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between group">
                        <div>
                          <h4 className="text-lg font-bold text-slate-800">{exam.title}</h4>
                          <div className="flex gap-4 mt-2">
                            <span className="text-xs font-bold text-slate-400 flex items-center gap-1"><Clock className="w-3 h-3" /> {exam.duration}m</span>
                            <span className="text-xs font-bold text-slate-400 flex items-center gap-1"><Users className="w-3 h-3" /> {results.filter(r => r.examId === exam.id).length} attempts</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => deleteExam(exam.id)}
                            className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-slate-700 mb-4">Submission Feed</h3>
                  <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                    {results.length === 0 ? (
                      <div className="p-12 text-center text-slate-400">No data</div>
                    ) : (
                      <div className="divide-y divide-slate-50">
                        {results.slice().reverse().map((res) => (
                          <div key={res.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                            <div>
                              <div className="font-bold text-sm">{res.studentName}</div>
                              <div className="text-[10px] text-slate-400 font-bold uppercase">{res.examTitle}</div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-indigo-600">{res.score}/{res.totalQuestions}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Exam Taking View */}
          {view === 'exam-taking' && currentExam && (
            <motion.div 
              key="exam-taking"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="max-w-4xl mx-auto"
            >
              {showInstructions ? (
                <div className="bg-white p-12 rounded-3xl shadow-xl border border-slate-100 text-center">
                  <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <ClipboardList className="w-10 h-10" />
                  </div>
                  <h2 className="text-3xl font-bold mb-4">{currentExam.title} Instructions</h2>
                  <div className="max-w-md mx-auto text-left bg-slate-50 p-6 rounded-2xl mb-8 space-y-3 text-slate-600">
                    <p>• Total Questions: <strong>{currentExam.questions.length}</strong></p>
                    <p>• Time Limit: <strong>{currentExam.duration} Minutes</strong></p>
                    <p>• Do not refresh the page during the exam.</p>
                    <p>• Your progress is auto-saved if you disconnect.</p>
                    <p>• The exam will auto-submit when the timer hits zero.</p>
                  </div>
                  <button 
                    onClick={() => setShowInstructions(false)}
                    className="bg-indigo-600 text-white px-12 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all"
                  >
                    Start Exam Now
                  </button>
                </div>
              ) : (
                <>
                  <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 mb-6 sticky top-20 z-10">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="text-xl font-bold text-indigo-600">{currentExam.title}</h2>
                        <p className="text-sm text-slate-500 font-medium">Question {currentQuestionIndex + 1} of {currentExam.questions.length}</p>
                      </div>
                      <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold text-xl ${timeLeft < 60 ? 'bg-rose-50 text-rose-600 animate-pulse' : 'bg-slate-100 text-slate-700'}`}>
                        <Clock className="w-5 h-5" />
                        {formatTime(timeLeft)}
                      </div>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 mt-4 rounded-full overflow-hidden">
                      <div 
                        className="bg-indigo-600 h-full transition-all duration-300"
                        style={{ width: `${((currentQuestionIndex + 1) / currentExam.questions.length) * 100}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 min-h-[400px] flex flex-col">
                    <div className="mb-4">
                       <span className="text-xs font-bold text-indigo-500 uppercase tracking-widest">Question {currentQuestionIndex + 1}</span>
                       <h3 className="text-2xl font-bold text-slate-800 mt-2">
                         {currentExam.questions[currentQuestionIndex].text}
                       </h3>
                    </div>

                    <div className="space-y-4 flex-grow mt-6">
                      {currentExam.questions[currentQuestionIndex].options.map((option, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            const newAns = [...studentAnswers];
                            newAns[currentQuestionIndex] = idx;
                            setStudentAnswers(newAns);
                          }}
                          className={`w-full p-5 rounded-2xl border-2 text-left transition-all flex items-center justify-between group
                            ${studentAnswers[currentQuestionIndex] === idx 
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-700' 
                              : 'border-slate-100 hover:border-slate-200 text-slate-600 bg-slate-50/50'}`}
                        >
                          <span className="flex items-center gap-4">
                            <span className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg
                              ${studentAnswers[currentQuestionIndex] === idx ? 'bg-indigo-600 text-white' : 'bg-white text-slate-400 border border-slate-200'}`}>
                              {String.fromCharCode(65 + idx)}
                            </span>
                            <span className="font-semibold">{option}</span>
                          </span>
                          {studentAnswers[currentQuestionIndex] === idx && (
                            <div className="bg-indigo-600 p-1 rounded-full"><CheckCircle2 className="w-5 h-5 text-white" /></div>
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center justify-between mt-12 pt-8 border-t border-slate-100">
                      <button
                        disabled={currentQuestionIndex === 0}
                        onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
                        className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-slate-400 disabled:opacity-0 hover:bg-slate-50 transition-all"
                      >
                        <ChevronLeft className="w-5 h-5" /> Previous
                      </button>
                      
                      {currentQuestionIndex === currentExam.questions.length - 1 ? (
                        <button
                          onClick={() => confirm('Are you sure you want to submit your exam?') && submitExam()}
                          className="bg-emerald-600 text-white px-10 py-3 rounded-xl font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-100 transition-all"
                        >
                          Finish & Submit
                        </button>
                      ) : (
                        <button
                          onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
                          className="flex items-center gap-2 px-8 py-3 rounded-xl font-bold bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all"
                        >
                          Next Question <ChevronRight className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </div>
                  
                  {/* Quick Nav */}
                  <div className="mt-8 flex flex-wrap gap-2 justify-center">
                    {currentExam.questions.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentQuestionIndex(i)}
                        className={`w-10 h-10 rounded-lg font-bold text-sm transition-all
                          ${currentQuestionIndex === i ? 'ring-2 ring-indigo-600 ring-offset-2' : ''}
                          ${studentAnswers[i] !== -1 ? 'bg-indigo-600 text-white' : 'bg-white text-slate-400 border border-slate-200'}`}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </motion.div>
          )}

          {/* Results View */}
          {view === 'results' && activeResult && (
            <motion.div 
              key="results"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto text-center"
            >
              <div className="bg-white p-12 rounded-3xl shadow-xl border border-slate-100">
                <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald-600">
                  <Trophy className="w-12 h-12" />
                </div>
                <h2 className="text-3xl font-bold mb-2">Congratulations, {activeResult.studentName}!</h2>
                <p className="text-slate-500 mb-8">You have successfully completed the exam.</p>
                
                <div className="grid grid-cols-2 gap-4 mb-10">
                  <div className="bg-slate-50 p-6 rounded-2xl">
                    <div className="text-sm text-slate-500 mb-1">Total Score</div>
                    <div className="text-4xl font-black text-indigo-600">{activeResult.score} / {activeResult.totalQuestions}</div>
                  </div>
                  <div className="bg-slate-50 p-6 rounded-2xl">
                    <div className="text-sm text-slate-500 mb-1">Percentage</div>
                    <div className="text-4xl font-black text-emerald-600">
                      {Math.round((activeResult.score / activeResult.totalQuestions) * 100)}%
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setView('landing')}
                  className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 transition-colors"
                >
                  Return to Home
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="py-8 text-center text-slate-400 text-sm">
        <p>© {new Date().getFullYear()} SmartCBT School System. Powered by <strong>boommack</strong></p>
      </footer>
    </div>
  );
}

function ExamCreator({ onSave, onCancel }: { onSave: (exam: Exam) => void, onCancel: () => void }) {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [duration, setDuration] = useState(30);
  const [questions, setQuestions] = useState<Partial<Question>[]>([{
    id: generateId(),
    text: '',
    options: ['', '', '', ''],
    correctAnswer: 0
  }]);

  const addQuestion = () => {
    setQuestions([...questions, {
      id: generateId(),
      text: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    }]);
  };

  const updateQuestion = (idx: number, field: keyof Question, value: any) => {
    const next = [...questions];
    next[idx] = { ...next[idx], [field]: value };
    setQuestions(next);
  };

  const updateOption = (qIdx: number, oIdx: number, value: string) => {
    const next = [...questions];
    const opts = [...(next[qIdx].options || [])];
    opts[oIdx] = value;
    next[qIdx].options = opts;
    setQuestions(next);
  };

  const handleSave = () => {
    if (!title || questions.some(q => !q.text)) {
      alert('Please fill in all fields');
      return;
    }
    onSave({
      id: generateId(),
      title,
      description: desc,
      duration,
      questions: questions as Question[],
      createdAt: Date.now()
    });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto pb-20">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold">Setup New Exam</h2>
        <div className="flex gap-4">
          <button onClick={onCancel} className="px-6 py-2 text-slate-600 font-semibold">Cancel</button>
          <button onClick={handleSave} className="bg-indigo-600 text-white px-8 py-2 rounded-xl font-bold shadow-lg hover:bg-indigo-700">Publish Exam</button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Exam Title</label>
            <input 
              value={title} 
              onChange={e => setTitle(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none" 
              placeholder="e.g. Physics Final Exam"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Short Description</label>
            <textarea 
              value={desc}
              onChange={e => setDesc(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none h-20"
              placeholder="What is this exam about?"
            />
          </div>
          <div className="w-32">
            <label className="block text-sm font-semibold text-slate-700 mb-1">Time (Mins)</label>
            <input 
              type="number" 
              value={duration}
              onChange={e => setDuration(parseInt(e.target.value))}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-bold pt-4">Questions</h3>
          {questions.map((q, qIdx) => (
            <div key={q.id} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 space-y-4 relative">
              <span className="absolute -left-3 top-8 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold shadow-lg">
                {qIdx + 1}
              </span>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Question Text</label>
                <input 
                  value={q.text}
                  onChange={e => updateQuestion(qIdx, 'text', e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none" 
                  placeholder="Enter the question here..."
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {q.options?.map((opt, oIdx) => (
                  <div key={oIdx} className="flex gap-2">
                    <input 
                      type="radio" 
                      name={`correct-${q.id}`} 
                      checked={q.correctAnswer === oIdx}
                      onChange={() => updateQuestion(qIdx, 'correctAnswer', oIdx)}
                      className="mt-4 accent-emerald-500 w-5 h-5"
                    />
                    <div className="flex-grow">
                      <label className="text-xs text-slate-400 mb-1 block">Option {String.fromCharCode(65 + oIdx)}</label>
                      <input 
                        value={opt}
                        onChange={e => updateOption(qIdx, oIdx, e.target.value)}
                        className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          
          <button 
            onClick={addQuestion}
            className="w-full py-4 border-2 border-dashed border-slate-300 rounded-2xl text-slate-500 font-bold hover:border-indigo-400 hover:text-indigo-500 transition-all flex items-center justify-center gap-2"
          >
            <PlusCircle className="w-5 h-5" /> Add Another Question
          </button>
        </div>
      </div>
    </motion.div>
  );
}
