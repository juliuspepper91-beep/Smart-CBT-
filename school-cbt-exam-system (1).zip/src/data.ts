import { Exam } from './types';

export const INITIAL_EXAMS: Exam[] = [
  {
    id: '1',
    title: 'Mathematics Essentials',
    description: 'Basic algebra, geometry, and arithmetic reasoning.',
    duration: 30,
    createdAt: Date.now(),
    questions: [
      {
        id: 'q1',
        text: 'What is the value of x in 2x + 5 = 15?',
        options: ['2', '5', '10', '15'],
        correctAnswer: 1
      },
      {
        id: 'q2',
        text: 'What is the area of a circle with radius 7? (Use pi = 22/7)',
        options: ['154', '44', '49', '14'],
        correctAnswer: 0
      }
    ]
  },
  {
    id: '2',
    title: 'General Science',
    description: 'Fundamental concepts of Biology, Physics, and Chemistry.',
    duration: 20,
    createdAt: Date.now(),
    questions: [
      {
        id: 's1',
        text: 'Which planet is known as the Red Planet?',
        options: ['Venus', 'Jupiter', 'Mars', 'Saturn'],
        correctAnswer: 2
      },
      {
        id: 's2',
        text: 'What is the chemical symbol for Water?',
        options: ['CO2', 'H2O', 'O2', 'NaCl'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: '3',
    title: 'English Literacy',
    description: 'Grammar, vocabulary, and reading comprehension.',
    duration: 15,
    createdAt: Date.now(),
    questions: [
      {
        id: 'e1',
        text: 'Identify the synonym for "Happy".',
        options: ['Sad', 'Angry', 'Joyful', 'Tired'],
        correctAnswer: 2
      },
      {
        id: 'e2',
        text: 'Which of these is a noun?',
        options: ['Run', 'Beautiful', 'Quickly', 'Table'],
        correctAnswer: 3
      }
    ]
  }
];
